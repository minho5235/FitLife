"""FitLife AI 2.0"""
from . import models, rag, xai, utils, vision, data
__version__ = "2.0.0"
